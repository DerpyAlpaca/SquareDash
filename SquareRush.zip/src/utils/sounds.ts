class SoundManager {
  private ctx: AudioContext | null = null;
  private music: HTMLAudioElement | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Context will be created on first interaction
  }

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public playHit() {
    this.initCtx();
    if (this.isMuted || !this.ctx) return;

    // Very quiet "thud" sound
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(100, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, this.ctx.currentTime + 0.1);

    gain.gain.setValueAtTime(0.04, this.ctx.currentTime); // Very quiet
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.1);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.1);
  }

  public playFail() {
    this.initCtx();
    if (this.isMuted || !this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(55, this.ctx.currentTime + 0.5);

    gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.5);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.5);
  }

  public startMusic(customUrl?: string) {
    if (this.music) {
      this.music.pause();
      this.music.src = '';
      this.music.load();
    }

    // Using Midnight City as default since it's verified working for the user
    const defaultMusic = 'https://cdn.pixabay.com/audio/2022/01/18/audio_d0a13f69d2.mp3';
    this.music = new Audio(customUrl || defaultMusic);
    this.music.crossOrigin = "anonymous";
    this.music.loop = true;
    this.music.volume = 0.4;
    this.music.muted = this.isMuted;
    
    const playPromise = this.music.play();
    if (playPromise !== undefined) {
      playPromise.catch(e => {
        console.error("Playback failed:", e);
        const handleInteraction = () => {
          this.music?.play();
          window.removeEventListener('click', handleInteraction);
          window.removeEventListener('touchstart', handleInteraction);
        };
        window.addEventListener('click', handleInteraction);
        window.addEventListener('touchstart', handleInteraction);
      });
    }
  }

  public stopMusic() {
    if (this.music) {
      this.music.pause();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.music) {
      this.music.muted = muted;
    }
  }

  public getMusicTime() {
    return this.music ? this.music.currentTime : 0;
  }
}

export const sounds = new SoundManager();
